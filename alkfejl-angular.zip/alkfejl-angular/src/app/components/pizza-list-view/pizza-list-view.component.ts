import { Component, OnInit } from '@angular/core';
import { Pizza } from '../../classes/pizza';
import { Topping } from "../../classes/topping";
import { PizzaService } from '../../services/pizza.service';

@Component({
  selector: 'app-pizza-list-view',
  templateUrl: './pizza-list-view.component.html',
  styleUrls: ['./pizza-list-view.component.css'],
  providers: [PizzaService]
})
export class PizzaListViewComponent implements OnInit {

    private pizzas: Pizza[];
    private toppings1: Topping[];
    private toppings2: Topping[];
    private toppings3: Topping[];
  
    constructor(private pizzaService: PizzaService) {}
  
    ngOnInit() {
      this.pizzaService.getAll().subscribe((pizzas) => {
        this.pizzas = pizzas as Pizza[];
      });
    }
}
