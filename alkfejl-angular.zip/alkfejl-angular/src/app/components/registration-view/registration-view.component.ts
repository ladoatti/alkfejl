import { Component, OnInit } from '@angular/core';
import { User } from "../../classes/user";
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-registration-view',
  templateUrl: './registration-view.component.html',
  styleUrls: ['./registration-view.component.css'],
  providers: [UserService]
})
export class RegistrationViewComponent implements OnInit {
  private static id: number = 2;
  private user : User;

  constructor(private userService: UserService) { }

  ngOnInit() {
  }

  private registration(name: string, email: string, password: string, tel: string, address: string) : void {
    this.user = new User(RegistrationViewComponent.id++, name, email, password, tel, address, "USER");
    this.userService.addUser(this.user).subscribe();
  }

}
