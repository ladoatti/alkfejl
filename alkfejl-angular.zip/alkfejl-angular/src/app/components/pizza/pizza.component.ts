import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Pizza } from '../../classes/pizza';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-pizza',
  templateUrl: './pizza.component.html',
  styleUrls: ['./pizza.component.css'],
  providers: [AuthService]
})
export class PizzaComponent implements OnInit {
  @Input()
  public pizza: Pizza;

  constructor(
    private authService: AuthService
  ) { }

  ngOnInit() {
  }

}
