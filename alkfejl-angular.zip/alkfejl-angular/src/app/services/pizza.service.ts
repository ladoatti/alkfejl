import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs/Observable';
import { Pizza } from '../classes/pizza';

@Injectable()
export class PizzaService {

  private static api: string = 'http://localhost:4200/api/Pizzas';

  constructor(private http: HttpClient) { }

  public get(id: number): Observable<Pizza> {
    return this.http.get<Pizza>(PizzaService.api + '/' + id);
  }

  public getAll(): Observable<Pizza[]> {
    return this.http.get(PizzaService.api + "/getall") as Observable<Pizza[]>;
  }
}
