import { browser, by, element } from 'protractor';
import { getPath } from './getpath';

describe('Fiok functionality', () => {
    beforeEach(() => {
        browser.get('/login');
        element(by.css('input[type="email"]')).sendKeys('fos@fos.hu');
        element(by.css('input[type="password"]')).sendKeys('1234');
        element(by.css('input[type="button"]')).click();
        browser.get('/user/:id');
    })

    it('should be able to navigate to fiok', () => {
        expect(getPath()).toEqual('/user/:id');
    })

    it('shouldn"t be able to navigate to fiok if not logged in', () => {
        browser.get('/logout');
        browser.get('/user/:id');
        expect(getPath()).toEqual('/login');
    })
})